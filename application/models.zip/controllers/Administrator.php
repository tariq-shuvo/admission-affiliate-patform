<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: Shuvo
 * Date: 5/2/2018
 * Time: 2:16 PM
 */
class Administrator extends CI_Controller
{
    public function mentors($id=1)
    {
        $offset=($id*per_page)-per_page;
        $data['serial']=$offset+1;
        $this->load->model('administratorModel');

        if($this->session->has_userdata('user_data_info') && $this->session->has_userdata('user_validation')){
            if($this->session->userdata('user_validation')==true)
            {
                $data['title']="All Mentors";
                $data['result']=$this->administratorModel->all_mentors($offset);
                $data['navigation']='mentors';
                $data['pagination']=$this->administratorModel->pagination_html($this->administratorModel->count_all_rows('mentors'),'administrator/mentors/',$id);


                $this->load->view('dashboard/header.php',$data);
                $this->load->view('dashboard/mentors.php',$data);
                $this->load->view('dashboard/footer.php');
            }else{
                redirect('dashboard');
            }

        }else{
            if(isset($_COOKIE['user_data_info'])==true && isset($_COOKIE['user_validation'])==true){
                if(get_cookie('user_validation')==true){

                    $data['title']="All Mentors";
                    $data['result']=$this->administratorModel->all_mentors($offset);
                    $data['navigation']='mentors';
                    $data['pagination']=$this->administratorModel->pagination_html($this->administratorModel->count_all_rows('mentors'),'administrator/mentors/',$id);

                    $this->load->view('dashboard/header.php',$data);
                    $this->load->view('dashboard/mentors.php',$data);
                    $this->load->view('dashboard/footer.php');
                }else{
                    redirect('dashboard');
                }
            }else{
                redirect('dashboard');
            }
        }
    }

    public function courses($id=1)
    {
        $offset=($id*per_page)-per_page;
        $data['serial']=$offset+1;
        $this->load->model('administratorModel');

        if($this->session->has_userdata('user_data_info') && $this->session->has_userdata('user_validation')){
            if($this->session->userdata('user_validation')==true)
            {
                $data['title']="All Courses";
                $data['result']=$this->administratorModel->all_courses($offset);

                $data['mentors']=$this->administratorModel->all_mentors();
                $data['navigation']='courses';

                $data['pagination']=$this->administratorModel->pagination_html($this->administratorModel->count_all_rows('courses'),'administrator/courses/',$id);


                $this->load->view('dashboard/header.php',$data);
                $this->load->view('dashboard/courses.php',$data);
                $this->load->view('dashboard/footer.php');
            }else{
                redirect('dashboard');
            }

        }else{
            if(isset($_COOKIE['user_data_info'])==true && isset($_COOKIE['user_validation'])==true){
                if(get_cookie('user_validation')==true){

                    $data['title']="All Courses";
                    $data['result']=$this->administratorModel->all_courses($offset);
                    $data['mentors']=$this->administratorModel->all_mentors();
                    $data['navigation']='courses';
                    $data['pagination']=$this->administratorModel->pagination_html($this->administratorModel->count_all_rows('courses'),'administrator/courses/',$id);

                    $this->load->view('dashboard/header.php',$data);
                    $this->load->view('dashboard/courses.php',$data);
                    $this->load->view('dashboard/footer.php');
                }else{
                    redirect('dashboard');
                }
            }else{
                redirect('dashboard');
            }
        }
    }

    public function search_course($search=null,$search_value=null,$id=1)
    {
        if($search_value==null || $search_value==null)
        {
            redirect('administrator/courses');
        }
        $offset=($id*per_page)-per_page;
        $data['serial']=$offset+1;
        $this->load->model('administratorModel');

        if($search=='mentor')
        {
            $column_name="mentor_name";
            $search_value=urldecode(trim($search_value));
        }else{
            $column_name="batch_name";
        }

        if($this->session->has_userdata('user_data_info') && $this->session->has_userdata('user_validation')){
            if($this->session->userdata('user_validation')==true)
            {
                $data['title']="Search Courses";
                $data['result']=$this->administratorModel->search_all_courses($offset,$column_name,strtoupper($search_value));

                $data['mentors']=$this->administratorModel->all_mentors();

                $data['pagination']=$this->administratorModel->pagination_html($this->administratorModel->search_count_all_rows('courses',$column_name,strtoupper($search_value)),'administrator/search_course/'.$search.'/'.$search_value.'/',$id);

                $data['search_value']=$search_value;


                $this->load->view('dashboard/header.php',$data);
                $this->load->view('dashboard/courses.php',$data);
                $this->load->view('dashboard/footer.php');
            }else{
                redirect('administrator/courses');
            }

        }else{
            if(isset($_COOKIE['user_data_info'])==true && isset($_COOKIE['user_validation'])==true){
                if(get_cookie('user_validation')==true){

                    $data['title']="Search Courses";
                    $data['result']=$this->administratorModel->search_all_courses($offset,$column_name,strtoupper($search_value));

                    $data['mentors']=$this->administratorModel->all_mentors();

                    $data['pagination']=$this->administratorModel->pagination_html($this->administratorModel->search_count_all_rows('courses',$column_name,strtoupper($search_value)),'administrator/search_course/'.$search.'/'.$search_value.'/',$id);

                    $data['search_value']=$search_value;

                    $this->load->view('dashboard/header.php',$data);
                    $this->load->view('dashboard/courses.php',$data);
                    $this->load->view('dashboard/footer.php');
                }else{
                    redirect('administrator/courses');
                }
            }else{
                redirect('administrator/courses');
            }
        }

    }



    public function add_mentor()
    {
        $this->load->model('administratorModel');

        if($this->session->has_userdata('user_data_info') && $this->session->has_userdata('user_validation')){
            if($this->session->userdata('user_validation')==true)
            {
                if($this->input->post('admin_auth')=='base'){
                    $mentor_name=trim($this->input->post('mentorName'));

                    $mentor_data=array(
                        'mentor_name'=>$mentor_name
                    );
                    $result=$this->administratorModel->insert_mentor($mentor_data);

                    if($result==true){
                        $this->session->set_flashdata('notification', '<div class="alert alert-success"><strong>Success!</strong> New mentor added successfully.</div>');
                        redirect('administrator/mentors');
                    }
                }

            }else{
                redirect('dashboard');
            }

        }else{
            if(isset($_COOKIE['user_data_info'])==true && isset($_COOKIE['user_validation'])==true){
                if(get_cookie('user_validation')==true){

                    if($this->input->post('admin_auth')=='base'){
                        $mentor_name=trim($this->input->post('mentorName'));

                        $mentor_data=array(
                            'mentor_name'=>$mentor_name
                        );
                        $result=$this->administratorModel->insert_mentor($mentor_data);

                        if($result==true){
                            $this->session->set_flashdata('notification', '<div class="alert alert-success"><strong>Success!</strong> New mentor added successfully.</div>');
                            redirect('administrator/mentors');
                        }
                    }
                }else{
                    redirect('dashboard');
                }
            }else{
                redirect('dashboard');
            }
        }


    }

    public function edit_mentor()
    {
        $this->load->model('administratorModel');

        if($this->session->has_userdata('user_data_info') && $this->session->has_userdata('user_validation')){
            if($this->session->userdata('user_validation')==true)
            {
                if($this->input->post('admin_auth')=='base'){
                    $mentor_name=trim($this->input->post('mentorName'));

                    $mentor_data=array(
                        'mentor_name'=>$mentor_name
                    );
                    $result=$this->administratorModel->insert_mentor($mentor_data);

                    if($result==true){
                        $this->session->set_flashdata('notification', '<div class="alert alert-success"><strong>Success!</strong> New mentor added successfully.</div>');
                        redirect('administrator/mentors');
                    }
                }

            }else{
                redirect('dashboard');
            }

        }else{
            if(isset($_COOKIE['user_data_info'])==true && isset($_COOKIE['user_validation'])==true){
                if(get_cookie('user_validation')==true){

                    if($this->input->post('admin_auth')=='base'){
                        $mentor_name=trim($this->input->post('mentorName'));

                        $mentor_data=array(
                            'mentor_name'=>$mentor_name
                        );
                        $result=$this->administratorModel->insert_mentor($mentor_data);

                        if($result==true){
                            $this->session->set_flashdata('notification', '<div class="alert alert-success"><strong>Success!</strong> New mentor added successfully.</div>');
                            redirect('administrator/mentors');
                        }
                    }
                }else{
                    redirect('dashboard');
                }
            }else{
                redirect('dashboard');
            }
        }


    }

    public function add_course()
    {
        $this->load->model('administratorModel');

        if($this->session->has_userdata('user_data_info') && $this->session->has_userdata('user_validation')){
            if($this->session->userdata('user_validation')==true)
            {
                if($this->input->post('admin_auth')=='base'){
                    $batchName=trim($this->input->post('batchName'));
                    $batchTitle=trim($this->input->post('batchTitle'));
                    $courseType=trim($this->input->post('courseType'));
                    $courseDuration=trim($this->input->post('courseDuration'));
                    $summery=trim($this->input->post('summery'));
                    $mentorName=trim($this->input->post('mentorName'));


                    $course_data=array(
                        'batch_title'=>$batchTitle,
                        'batch_name'=>$batchName,
                        'course_type'=>$courseType,
                        'duration'=>$courseDuration,
                        'summery'=>$summery,
                        'mentor_name'=>$mentorName,
                    );
                    $result=$this->administratorModel->insert_course($course_data);

                    if($result==true){
                        $this->session->set_flashdata('notification', '<div class="alert alert-success"><strong>Success!</strong> New course added successfully.</div>');
                        redirect('administrator/courses');
                    }
                }
            }else{
                redirect('dashboard');
            }

        }else{
            if(isset($_COOKIE['user_data_info'])==true && isset($_COOKIE['user_validation'])==true){
                if(get_cookie('user_validation')==true){

                    if($this->input->post('admin_auth')=='base'){
                        $batchName=trim($this->input->post('batchName'));
                        $batchTitle=trim($this->input->post('batchTitle'));
                        $courseType=trim($this->input->post('courseType'));
                        $courseDuration=trim($this->input->post('courseDuration'));
                        $summery=trim($this->input->post('summery'));
                        $mentorName=trim($this->input->post('mentorName'));


                        $course_data=array(
                            'batch_title'=>$batchTitle,
                            'batch_name'=>$batchName,
                            'course_type'=>$courseType,
                            'duration'=>$courseDuration,
                            'summery'=>$summery,
                            'mentor_name'=>$mentorName,
                        );
                        $result=$this->administratorModel->insert_course($course_data);

                        if($result==true){
                            $this->session->set_flashdata('notification', '<div class="alert alert-success"><strong>Success!</strong> New course added successfully.</div>');
                            redirect('administrator/courses');
                        }
                    }
                }else{
                    redirect('dashboard');
                }
            }else{
                redirect('dashboard');
            }
        }

    }

    public function update_course()
    {
        $this->load->model('administratorModel');

        if($this->session->has_userdata('user_data_info') && $this->session->has_userdata('user_validation')){
            if($this->session->userdata('user_validation')==true)
            {
                if($this->input->post('admin_auth')=='base'){
                    $editID=trim($this->input->post('editID'));
                    $batchID=trim($this->input->post('batchID'));
                    $batchName=trim($this->input->post('batchName'));
                    $batchTitle=trim($this->input->post('batchTitle'));
                    $courseType=trim($this->input->post('courseType'));
                    $courseDuration=trim($this->input->post('courseDuration'));
                    $summery=trim($this->input->post('summery'));
                    $mentorName=trim($this->input->post('mentorName'));


                    $course_data=array(
                        'batch_title'=>$batchTitle,
                        'batch_name'=>$batchName,
                        'course_type'=>$courseType,
                        'duration'=>$courseDuration,
                        'summery'=>$summery,
                        'mentor_name'=>$mentorName
                    );

                    $student_data=array(
                        'course_name'=>$batchTitle,
                        'batch_name'=>$batchName,
                        'course_type'=>$courseType,
                        'course_duration'=>$courseDuration,
                        'mentor_name'=>$mentorName
                    );

                    $result=$this->administratorModel->update_course($course_data,$student_data,$editID,$batchID);

                    if($result==true){
                        $this->session->set_flashdata('notification', '<div class="alert alert-success"><strong>Success!</strong> Course updated successfully.</div>');
                        redirect('administrator/courses');
                    }
                }
            }else{
                redirect('dashboard');
            }

        }else{
            if(isset($_COOKIE['user_data_info'])==true && isset($_COOKIE['user_validation'])==true){
                if(get_cookie('user_validation')==true){

                    if($this->input->post('admin_auth')=='base'){

                    }
                }else{
                    redirect('dashboard');
                }
            }else{
                redirect('dashboard');
            }
        }
    }

    public function edit_course()
    {
        $this->load->model('administratorModel');

        if($this->session->has_userdata('user_data_info') && $this->session->has_userdata('user_validation')){
            if($this->session->userdata('user_validation')==true)
            {
                if($this->input->post('admin_auth')=='base'){
                    $edit_id=trim($this->input->post('edit_id'));
                    $data['course']=$this->administratorModel->course($edit_id);
                    $data['mentors']=$this->administratorModel->mentors();

                    $this->load->view('dashboard/edit_course.php',$data);
                }
            }else{
                redirect('dashboard');
            }

        }else{
            if(isset($_COOKIE['user_data_info'])==true && isset($_COOKIE['user_validation'])==true){
                if(get_cookie('user_validation')==true){

                    if($this->input->post('admin_auth')=='base'){
                        $edit_id=trim($this->input->post('edit_id'));
                        $data['course']=$this->administratorModel->course($edit_id);
                        $this->load->view('dashboard/edit_course.php',$data);
                    }
                }else{
                    redirect('dashboard');
                }
            }else{
                redirect('dashboard');
            }
        }

    }

    public function course_delete($id)
    {
        $this->load->model('administratorModel');

        if($this->session->has_userdata('user_data_info') && $this->session->has_userdata('user_validation')){
            if($this->session->userdata('user_validation')==true)
            {
                if($id!=null){
                    $result=$this->administratorModel->delete_course($id);

                    if($result==true){
                        $this->session->set_flashdata('notification', '<div class="alert alert-success"><strong>Success!</strong> Course deleted successfully.</div>');
                        redirect('administrator/courses');
                    }
                }else{
                    redirect('dashboard');
                }
            }else{
                redirect('dashboard');
            }

        }else{
            if(isset($_COOKIE['user_data_info'])==true && isset($_COOKIE['user_validation'])==true){
                if(get_cookie('user_validation')==true){

                    if($id!=null){
                        $result=$this->administratorModel->delete_course($id);

                        if($result==true){
                            $this->session->set_flashdata('notification', '<div class="alert alert-success"><strong>Success!</strong> Course deleted successfully.</div>');
                            redirect('administrator/courses');
                        }
                    }else{
                        redirect('dashboard');
                    }
                }else{
                    redirect('dashboard');
                }
            }else{
                redirect('dashboard');
            }
        }

    }
}