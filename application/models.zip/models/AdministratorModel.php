<?php

/**
 * Created by PhpStorm.
 * User: Shuvo
 * Date: 5/2/2018
 * Time: 2:18 PM
 */
class AdministratorModel extends CI_Model
{

    public function pagination_html($total_pages,$urls,$page_id=null)
    {
        $active_page=($page_id==null)?1:$page_id;


        $total_rows = ceil($total_pages/per_page);

        $pagination ='<ul class="pagination justify-content-center">';
        if($page_id==null || $page_id==1)
        {
            $pagination .='<li class="page-item disabled"><a class="page-link" href="'.base_url($urls).'" tabindex="-1"><i class="fas fa-caret-left"></i></a></li>';
        }else{
            $pagination .='<li class="page-item"><a class="page-link" href="'.base_url($urls.($active_page-1)).'"><i class="fas fa-caret-left"></i></a></li>';
        }
        for($i=1;$i<=$total_rows;$i++){

            if($i==$active_page){
                $pagination .='<li class="page-item active"><a class="page-link" href="'.base_url($urls.$i).'">'.$i.'</a></li>';
            }else{
                $pagination .='<li class="page-item"><a class="page-link" href="'.base_url($urls.$i).'">'.$i.'</a></li>';
            }

        }
        if($page_id==$total_rows)
        {
            $pagination .='<li class="page-item disabled"><a class="page-link" href="'.base_url($urls.$i).'"><i class="fas fa-caret-right"></i></a></li>';
        }else{
            $pagination .='<li class="page-item"><a class="page-link" href="'.base_url($urls.($active_page+1)).'"><i class="fas fa-caret-right"></i></a></li>';
        }
        $pagination .='</ul>';


        return $pagination;
    }

    public function count_all_rows($table_name)
    {
        $this->db->select("*");
        $this->db->from($table_name);
        $query = $this->db->get();

        return $query->num_rows();
    }

    public function all_mentors($offset=0)
    {
        $this->db->select("id, mentor_name");
        $this->db->from("mentors");
        $this->db->order_by("id","asc");
        $this->db->limit(per_page,$offset);
        $query = $this->db->get();
        return $query->result();
    }

    public function all_courses($offset=0)
    {
        $this->db->select("id, batch_name, course_type, mentor_name");
        $this->db->from("courses");
        $this->db->order_by("id","desc");
        $this->db->limit(per_page,$offset);
        $query = $this->db->get();
        return $query->result();
    }

    public function search_all_courses($offset=0,$column_name,$value)
    {
        $this->db->select("id, batch_name, course_type, mentor_name");
        $this->db->from("courses");
        $this->db->like($column_name,$value,'after');
        $this->db->order_by("id","desc");
        $this->db->limit(per_page,$offset);
        $query = $this->db->get();
        return $query->result();
    }

    public function search_count_all_rows($table_name,$column_name,$value)
    {
        $this->db->select("*");
        $this->db->from($table_name);
        $this->db->like("UPPER(".$column_name.")",$value,'after');
        $query = $this->db->get();

        return $query->num_rows();
    }

    public function course($id)
    {
        $this->db->select("*");
        $this->db->from("courses");
        $this->db->order_by("id","desc");
        $this->db->where('id',$id);
        $query = $this->db->get();
        return $query->result();
    }

    public function mentor($id)
    {
        $this->db->select("*");
        $this->db->from("mentors");
        $this->db->order_by("id","desc");
        $this->db->where('id',$id);
        $query = $this->db->get();
        return $query->result();
    }

    public function mentors()
    {
        $this->db->select("id, mentor_name");
        $this->db->from("mentors");
        $query = $this->db->get();
        return $query->result();

    }


    public function insert_mentor($mentor_data)
    {
        $this->db->insert('mentors', $mentor_data);

        return true;
    }

    public function insert_course($course_data)
    {
        $this->db->insert('courses', $course_data);

        return true;
    }

    public function update_course($courseData,$studentData,$edit_id,$batch_id)
    {
        $this->db->update('courses', $courseData, array('id' => $edit_id));
        $this->db->update('students', $studentData, array('batch_name' => $batch_id));
        return true;
    }

    public function delete_course($id)
    {
        $this->db->delete('courses', array('id' => $id));
        return true;
    }


}