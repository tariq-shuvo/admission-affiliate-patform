<section class="full_database">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-9">
                <form class="form-group">
                    <input class="form-control custom_search" value="<?php if(isset($search_value)){echo $search_value;} ?>" id="courseSearch" type="search" placeholder="Search course info" aria-label="Search">
                </form>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 dorp text-right">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle dropdown_custom" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
                        Sort By
                    </button>
                    <div class="dropdown-menu text-center" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" id="batch_search" href="#">Batch Name</a>
                        <a class="dropdown-item" id="mentor_search" href="#">Mentor Name</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
<!--            <div class="col-lg-12">-->
<!--                <div class="breadc">-->
<!--                    <nav aria-label="breadcrumb">-->
<!--                        <ol class="breadcrumb">-->
<!--                            <li class="breadcrumb-item"><a href="--><?php //echo base_url('administrator/courses'); ?><!--">All Courses</a></li>-->
<!--                            <li class="breadcrumb-item active" aria-current="page">Searched Courses</li>-->
<!--                        </ol>-->
<!--                    </nav>-->
<!--                </div>-->
<!--            </div>-->
            <div class="col-lg-12 database">
                <p>All Courses</p>
            </div>
            <div class="col-12">
                <div class="notification">
                    <?php
                    if(isset($_SESSION['notification'])){
                        echo $this->session->flashdata('notification');
                    }
                    ?>
                </div>
            </div>
            <div class="col-12">
                <button class="btn btn-secondary dropdown_custom float-right" type="button"  data-toggle="modal" data-target="#addCourses">
                    Add Course
                </button>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <table class="table table-bordered text-center">
                    <thead>
                    <tr>
                        <th style="" scope="col">Serial</th>
                        <th style="" scope="col">Batch Name</th>
                        <th style="" scope="col">Course Type</th>
                        <th style="" scope="col">Mentor Name</th>
                        <th style="" scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    if(count($result)>0){
                        $i=$serial;
                        foreach ($result as $course) {
                            ?>
                            <tr>
                                <th scope="row"><?php echo $i; ?></th>
                                <td><?php echo $course->batch_name; ?></td>
                                <td><?php echo $course->course_type==1?"online":"offline"; ?></td>
                                <td><?php echo $course->mentor_name; ?></td>
                                <td class="text-center"><a href="" class="view_btn" data-id="<?php echo $course->id; ?>"><i class="fas fa-eye custom_icon"></i></a><a href="" class="edit_course_btn" data-id="<?php echo $course->id; ?>" data-toggle="modal" data-target="#updateCourses"><i
                                            class="fas fa-edit custom_icon"></i></a><a href="" data-toggle="modal" data-target="#deleteCourse" class="delete_course_btn" data-id="<?php echo $course->id; ?>"><i
                                            class="fas fa-times custom_icon"></i></a></td>
                            </tr>
                            <?php
                            $i++;
                        }
                    }else {
                        ?>
                        <tr>
                            <td colspan="5">No courses found.</td>
                        </tr>
                        <?php
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <nav aria-label="Page navigation example">
                    <?php echo $pagination; ?>
                </nav>
            </div>
        </div>
    </div>
</section>

<!-- Modal -->
<div class="modal fade" id="addCourses" tabindex="-1" role="dialog" aria-labelledby="addCourses" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Course</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo base_url('administrator/add_course'); ?>" name="" method="post">
                <input type="hidden" value="base" name="admin_auth">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="form-group">
                                <input class="form-control" id="batchTitle" name="batchTitle" aria-describedby="batchTitle" placeholder="Batch Title" type="text">
                            </div>
                            <div class="form-group">
                                <input class="form-control" id="batchName" name="batchName" aria-describedby="batchName" placeholder="Batch Name" type="text">
                            </div>
                            <div class="form-group">
                                <select class="form-control custom_bg" id="courseType" name="courseType">
                                    <option value="0">Course Type</option>
                                    <option value="1">Online</option>
                                    <option value="2">Offline</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <input class="form-control" id="courseDuration" name="courseDuration" aria-describedby="courseDuration" placeholder="Course Duration" type="text">
                            </div>
                            <div class="form-group">
                                <select class="form-control custom_bg" id="mentorName" name="mentorName">
                                    <option value="0">Select Mentor</option>
                                    <?php foreach ($mentors as $mentor){ ?>
                                    <option value="<?php echo $mentor->mentor_name; ?>"><?php echo $mentor->mentor_name; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" rows="3" id="summery" name="summery" placeholder="Summery"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Course</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="updateCourses" tabindex="-1" role="dialog" aria-labelledby="updateCourses" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Information</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="edit_course_content" action="<?php echo base_url('administrator/update_course'); ?>" name="" method="post">
            </form>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="deleteCourse">
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h5 class="modal-title">Confirmation</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
               Do you really want to delete this course?
            </div>

            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
                <a href="" class="btn btn-info" id="deleteConfirmBtn">Yes</a>
            </div>

        </div>
    </div>
</div>