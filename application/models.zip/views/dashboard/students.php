<section class="full_database">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-9">
                <form class="form-group">
                    <input class="form-control custom_search" value="<?php if(isset($search_value)){echo $search_value; } ?>" id="searchData" type="search" placeholder="Search Student info" aria-label="Search">
                </form>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 dorp text-right">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle dropdown_custom" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Sort By
                    </button>
                    <div class="dropdown-menu text-center" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" id="id_search" href="#">Id</a>
                        <a class="dropdown-item" id="batch_search" href="#">Batch</a>
                        <a class="dropdown-item" id="phone_search" href="#">Student phone</a>
                    </div>
                </div>
            </div>
        </div>


        <div class="row">
<!--            <div class="col-lg-12">-->
<!--                <div class="breadc">-->
<!--                    <nav aria-label="breadcrumb">-->
<!--                        <ol class="breadcrumb">-->
<!--                            <li class="breadcrumb-item"><a href="--><?php //echo base_url('students'); ?><!--">All Students</a></li>-->
<!--                            <li class="breadcrumb-item active" aria-current="page">Student Information Edit</li>-->
<!--                        </ol>-->
<!--                    </nav>-->
<!--                </div>-->
<!--            </div>-->
            <div class="col-lg-12 database">
                <p>Student Database</p>
            </div>
            <div class="col-12">
                <div class="notification">
                    <?php
                    if(isset($_SESSION['notification'])){
                        echo $this->session->flashdata('notification');
                    }
                    ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <table class="table table-bordered text-center">
                    <thead>
                    <tr>
                        <th style="width:25%;" scope="col">ID</th>
                        <th style="width:50%;" scope="col">Name</th>
                        <th style="width:25%;" scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    if(count($result)>0){
                        foreach ($result as $student) {
                            ?>
                            <tr>
                                <th scope="row"><?php echo $student->id; ?></th>
                                <td><?php echo $student->name; ?></td>
                                <td class="text-center"><a href="<?php echo base_url('students/view/'.$student->id); ?>" class="view_btn" data-id="<?php echo $student->id; ?>"><i class="fas fa-eye custom_icon"></i></a><a href="<?php echo base_url('students/edit/'.$student->id); ?>" class="edit_btn" data-id="<?php echo $student->id; ?>"><i
                                                class="fas fa-edit custom_icon"></i></a><a href="" data-toggle="modal" data-target="#deleteStudent" class="delete_students_btn" data-id="<?php echo $student->id; ?>"><i
                                                class="fas fa-times custom_icon"></i></a></td>
                            </tr>
                            <?php
                        }
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <nav aria-label="Page navigation example">
                    <?php echo $pagination; ?>
                </nav>
            </div>
        </div>
    </div>
</section>

<div class="modal fade" id="deleteStudent">
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h5 class="modal-title">Confirmation</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                Do you really want to delete this student?
            </div>

            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
                <a href="" class="btn btn-info" id="deleteConfirmBtn">Yes</a>
            </div>

        </div>
    </div>
</div>