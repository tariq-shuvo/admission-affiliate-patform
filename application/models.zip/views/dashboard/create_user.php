<section class="general_info">
    <div class="container">
        <!-- Page Header-->
        <header>

        </header>
        <!--=============== page design start =====================-->
        <!-- title -->
        <!-- form -->
        <div class="row">
            <div class="col-lg-12 heading">
                <div class="g_info">
                    <P>Create New User</P>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <form action="" method="" enctype="">
                    <!-- images and upload -->
                    <div class="row">
                        <div class="col-lg-3 padding_buttom">
                            <img src="<?php echo base_url('assets/images/person.jpg'); ?>" alt="person" height="110">
                        </div>
                        <div class="col-lg-5 file_padding_top">
                            <input id="a" name="a" type="file">
                        </div>
                        <div class="col-lg-4 file_padding_top">
                            <select class="form-control" id="exampleFormControlSelect1">
                                <option>Gender</option>
                                <option>Male</option>
                                <option>Female</option>
                                <option>Other</option>
                            </select>
                        </div>
                    </div>
                    <!-- form -->
                    <div class="row">
                        <div class="col-lg-12">
                            <!-- <form action="" method="" enctype=""> -->
                            <div class="form-group">
                                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Student ID">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Full Name">
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="E-mail">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Contact Number">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <button type="submit" class="btn btn-primary btn_custom">Submit</button>
                    </div>
            </div>
            </form>
            <div class="col-lg-6 border_left">
                <form action="" method="" enctype="">
                    <!-- images and upload -->
                    <div class="row">
                        <div class="col-lg-3 padding_buttom">
                            <img src="<?php echo base_url('assets/images/person.jpg'); ?>" alt="person" height="110px">
                        </div>
                        <div class="col-lg-5 file_padding_top">
                            <input id="a" name="a" type="file">
                        </div>
                        <div class="col-lg-4 file_padding_top">
                            <select class="form-control" id="exampleFormControlSelect1">
                                <option>Gender</option>
                                <option>Male</option>
                                <option>Female</option>
                                <option>Other</option>
                            </select>
                        </div>
                    </div>
                    <!-- form -->
                    <div class="row">
                        <div class="col-lg-12">
                            <!-- <form action="" method="" enctype=""> -->
                            <div class="form-group">
                                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Student ID">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Full Name">
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="E-mail">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Contact Number">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <button type="submit" class="btn btn-primary btn_custom">Edit</button>
                    </div>
                </form>
            </div>
        </div>


    </div>
    </div>
    <!--=============== page design end =====================-->
    </div>
</section>