<footer data-brackets-id='348' class="main-footer">
    <div data-brackets-id='349' class="container-fluid">
        <div data-brackets-id='350' class="row">
            <div data-brackets-id='351' class="col-sm-6">
                <p data-brackets-id='352'>ShikhbeShobai &copy; 2018</p>
            </div>
            <div data-brackets-id='353' class="col-sm-6 text-right">
                <p data-brackets-id='354'>Design by <a data-brackets-id='355' href="#">ShikhbeShobai</a></p>
            </div>
        </div>
    </div>
</footer>
</div>
<!-- JavaScript files-->
<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<!--Image Preview-->
<script data-brackets-id='358' src="<?php echo base_url('assets/js/dashboard/jquery.uploadPreview.min.js'); ?>"></script>
<!-- Main File-->
<script data-brackets-id='359' src="<?php echo base_url('assets/js/dashboard/front.js'); ?>"></script>
<script data-brackets-id='360' src="<?php echo base_url('assets/js/dashboard/apps.js'); ?>"></script>
<?php include('assets/js/dashboard/admission_app.php'); ?>
</body>
</html>